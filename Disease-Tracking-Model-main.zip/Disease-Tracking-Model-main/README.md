# Disease-Tracking-Model
Developed an advanced healthcare data management system using PostgreSQL to track and manage infectious diseases across multiple geographic regions. The system integrates operational database (OLTP) and data warehouse (OLAP) functionalities, enabling real-time surveillance and detailed analytics.
